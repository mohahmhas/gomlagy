class Urls {
  static const String api = 'https://www.gomlgy.com/api/v1';
  static const String public_api = 'https://www.gomlgy.com/public';
}
