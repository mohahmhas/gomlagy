import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/mainPage.dart';
import 'package:gomalgy/providers/localization/app_localizations.dart';

import 'package:gomalgy/screens/outhantication/log_screen.dart';
import 'package:gomalgy/screens/outhantication/regist.dart';
import 'package:gomalgy/screens/outhantication/send_code.dart';
import 'package:gomalgy/screens/payment/card_Payment.dart';
import 'package:gomalgy/screens/payment/checkout.dart';
import 'package:gomalgy/screens/payment/purchase_history.dart';
import 'package:gomalgy/screens/user/history.dart';
import 'package:gomalgy/screens/user/orderDetailsTemp.dart';
import 'package:gomalgy/screens/user/orderdetailshistory.dart';
import 'package:splashscreen/splashscreen.dart';
import './providers/auth.dart';
import './providers/localization/app_language.dart';
import 'package:flutter_phoenix/flutter_phoenix.dart';

//wellcom
void main() {
  runApp(
    Phoenix(
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return ProviderScope(child: Consumer(
      builder: (ctx, watch, child) {
        /////////////////////////////////////////////////////////
        final model = watch(appLanguageDataProvider);
        model.fetchLocale();
        return MaterialApp(
          locale: model.appLocal,
          supportedLocales: [
            Locale('en', 'US'),
            Locale('ar', ''),
          ],
          localizationsDelegates: [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
          ],
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            primaryColor: Colors.orange[900],
          ),
          routes: {
            LoginScreen.id: (context) => LoginScreen(),
            PurchaseHistory.id: (context) => PurchaseHistory(),
            SendCode.id: (context) => SendCode(),
            CheckOut.id: (context) => CheckOut(),
            HistoryPage.id: (context) => HistoryPage(),
            RegisterScreen.id: (context) => RegisterScreen(),
            SendCode.id: (context) => SendCode(),
            CheckOut.id: (context) => CheckOut(),
            CardPayment.id: (context) => CardPayment(),
            PurchaseHistory.id: (context) => PurchaseHistory(),
            OrdarDetails.id: (context) => OrdarDetails(),
            OederDetailsTemp.id: (context) => OederDetailsTemp(),
            MainPgae.id: (context) => MainPgae()
          },
          home: MainPgae(),
        );
      },
    ));
  }
}

class SplashWidget extends StatelessWidget {
  const SplashWidget({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Future<Widget> loadFromFuture() async {
      context.read(authDataProvider).tryAutoSignin();
      //  print(result);
      print('result');

      // <fetch data from server. ex. login>

      return Future.value(new MainPgae());
    }

    return SplashScreen(
      navigateAfterFuture: loadFromFuture(),
      //routeName: MainPgae.id,
      photoSize: 100,
      image: Image.asset("assets/logo_o_foreground.png"),
      // text: "Normal Text",
      //  textType: TextType.NormalText,

      backgroundColor: Color(0xffeb6824),
    );
  }
}
