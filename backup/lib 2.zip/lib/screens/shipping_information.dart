import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/screens/payment/fatwora.dart';
import '../providers/account_information.dart';
import 'package:gomalgy/providers/localization/app_localizations.dart';

class ShippingInformation extends StatefulWidget {
//  AccountInformation accountInformation ;
  @override
  _ShippingInformationState createState() => _ShippingInformationState();
}

class _ShippingInformationState extends State<ShippingInformation> {
  int isDefualt;

  @override
  Widget build(BuildContext context) {
    context
        .read(accountDataProvider)
        .getAccountInformationAddress(UserId: '137');
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context).translate('shipping_information'),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              margin: EdgeInsets.only(top: 15),
              child: Text(
                AppLocalizations.of(context)
                    .translate('choose_a_shipping_address'),
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
            ),
          ),
          Consumer(
            builder: (context, watch, child) {
              final accountInformation = watch(accountDataProvider);

              List<Widget> list = [];
              list = List.from(
                accountInformation.address.map((e) {
                  int id = e.id;
                  isDefualt = e.setDefault;
                  // print(e.city.toString());
                  return Container(
                    padding: EdgeInsets.all(8),
                    margin: EdgeInsets.only(
                      bottom: 10,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(e.addressdetails),
                            Text(e.city),
                            Text(e.postalCode),
                            Text(e.country),
                            Text(e.phone),
                          ],
                        ),
                        Checkbox(
                            value: isDefualt == 1 ? true : false,
                            onChanged: (bool newValue) {
                              context
                                  .read(accountDataProvider)
                                  .setDefaultAddress(id, newValue);
                            }),
                      ],
                    ),
                  );
                }),
              );
              return Container(
                height: MediaQuery.of(context).size.height * .78,
                width: MediaQuery.of(context).size.width,
                child: SingleChildScrollView(
                  child: Wrap(
                    direction: Axis.horizontal,
                    spacing: 8.0,
                    children: list,
                  ),
                ),
              );
            },
          ),
          GestureDetector(
            onTap: () {
              isDefualt == 1
                  ? Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => Fatwora()))
                  : null;
            },
            child: Container(
                padding: EdgeInsets.all(18),
                width: MediaQuery.of(context).size.width,
                color: Theme.of(context).primaryColor,
                child: Text(
                  AppLocalizations.of(context).translate('proceed_to_payment'),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                )
                /* TextButton(
                style: ElevatedButton.styleFrom(
                  primary: Theme.of(context).primaryColor  ,// background Color
                  onPrimary: Colors.white
                ),
                onPressed: (){},
                child: Text(AppLocalizations.of(context).translate('proceed_to_payment'),)
                ), */
                ),
          ),
        ],
      ),
    );
  }
}
