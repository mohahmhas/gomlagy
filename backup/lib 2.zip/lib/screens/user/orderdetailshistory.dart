import 'package:flutter/material.dart';
import 'package:gomalgy/providers/history_provider.dart';

import 'package:gomalgy/providers/orderDetailsProvider.dart';
import 'package:gomalgy/screens/user/orderDetailsTemp.dart';

class OrdarDetails extends StatelessWidget {
  static String id = 'OrdarDetails';

  @override
  Widget build(BuildContext context) {
    final data =
        ModalRoute.of(context).settings.arguments as Map<String, dynamic>;
    PurchasesHistory methodApi = PurchasesHistory();
    OrderDetailsProvider orderApi = OrderDetailsProvider();
    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          centerTitle: true,
          title: Text('Order Details'),
          backgroundColor: Theme.of(context).primaryColor,
        ),
        body: Container(
          height: MediaQuery.of(context).size.height / 2,
          child: ListView(
            children: [
              FutureBuilder(
                future: methodApi.fetchPurchaseHistory(),
                builder: (context, snapShot) {
                  print(snapShot.data);
                  print('object');
                  if (snapShot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  }

                  List<Widget> listup = List.from(snapShot.data.map((e) {
                    print('address' + e.address.toString());
                    return OederDetailsTemp(
                      //عايز اباص الداتا دي من الروت المعمول في history page
                      //عايز اباصي ال link
                      //في  المثود البتجيب الابي اي اسمها orderDetailsProvider
                      //معلش يا اسلام تعبك معيا جدا وربنا يقدرني واشرفك يا ليد
                      code: e.code.toString(),
                      date: e.date.toString(),
                      paymentStatus: e.paymentStatus.toString(),
                      grandTotal: double.parse(e.grandTotal.toString()),
                      address: e.address.toString(),
                      linke: e.link,
                    );
                  }));
                  print("listup.length");
                  print(listup.length);

                  return Wrap(
                    direction: Axis.vertical,
                    crossAxisAlignment: WrapCrossAlignment.start,

                    alignment: WrapAlignment.start,

                    //textDirection: TextDirection.rtl,
                    runAlignment: WrapAlignment.start,
                    //runSpacing: 3.0,
                    //spacing: 5.0,

                    // verticalDirection: VerticalDirection.up,
                    children: listup,
                  );
                },
              ),
              ////////////===================
              FutureBuilder(
                future: orderApi.fetchHistoryDetails(data['link']),
                builder: (context, snapShot) {
                  print(snapShot.data);
                  print('object');
                  if (snapShot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  }
                  if (snapShot.hasData) {
                    // print('islam' + snapShot.data.toString());

                    List<Widget> listup = List.from(snapShot.data.map((e) {
                      print(snapShot.data);
                      return OederDetailsTemp(
                        product: e.product.toString(),
                        paymentStatus: e.paymentStatus.toString(),
                        quantity: e.quantity,
                        subtotal: e.subtotal,
                        tax: e.tax,
                        price: e.price,
                        shipping_cost: e.shipping_cost,
                        coupon_discount: e.coupon_discount,
                      );
                    }));
                    return Wrap(
                      direction: Axis.horizontal,
                      crossAxisAlignment: WrapCrossAlignment.start,

                      alignment: WrapAlignment.start,

                      //textDirection: TextDirection.rtl,
                      runAlignment: WrapAlignment.start,
                      // runSpacing: 3.0,
                      // spacing: 5.0,

                      // verticalDirection: VerticalDirection.up,
                      children: listup,
                    );
                  } else {
                    return Text('try again');
                  }
                },
              ),
            ],
          ),
        ));
  }
}
