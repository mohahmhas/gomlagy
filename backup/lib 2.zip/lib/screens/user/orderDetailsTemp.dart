import 'package:flutter/material.dart';

class OederDetailsTemp extends StatelessWidget {
  static String id = 'OederDetailsTemp';

  final String code;
  final String date;
  final String paymentStatus;
  final double grandTotal;
  final String address;
  final String city;
  final String country;
  final String payment_type;
  final double subtotal;
  final double coupon_discount;
  final double tax;
  final double shipping_cost;
  final String product;
  final double price;
  final double quantity;

  final String linke; //

  const OederDetailsTemp({
    Key key,
    this.code,
    this.date,
    this.paymentStatus,
    this.grandTotal,
    this.address,
    this.city,
    this.country,
    this.payment_type,
    this.subtotal,
    this.coupon_discount, //
    this.tax, //
    this.shipping_cost, //
    this.product, //
    this.price, //
    this.quantity, //
    this.linke,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    final data =
        ModalRoute.of(context).settings.arguments as Map<String, dynamic>;
    print('data______');

    //print(data['subdata']);
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.95,
          height: MediaQuery.of(context).size.height,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              BuildRow(
                context: context,
                text1: 'order code ',
                text2: code,
                colorstext2: true,
                text3: "Shipping Method",
                text4: 'flat Shipping rate',
                colorstext4: false,
              ),
              SizedBox(
                height: height * 0.01,
              ),
              BuildRow(
                  context: context,
                  text1: 'order Date ',
                  text2: date,
                  colorstext2: false,
                  colorstext4: false,
                  text3: 'Shipping Method ',
                  text4: payment_type),
              SizedBox(
                height: height * 0.01,
              ),
              BuildRow(
                context: context,
                text1: 'Payment Status',
                text2: paymentStatus,
                colorstext2: true,
                text3: 'Total Amount',
                text4: '${grandTotal}' + 'ج.م',
                colorstext4: true,
              ),
              SizedBox(
                height: height * 0.01,
              ),
              Text(
                'Shipping Address ',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                address ?? '' + ',' + city ?? '' + ',' + country ?? '',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Ordered Products',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                  )
                ],
              ),
              SizedBox(
                height: height * 0.01,
              ),
              Text(
                product ?? '',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    quantity.toString() ?? '',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(
                height: height * 0.01,
              ),
              SubTitel(
                  fText: 'PENDING',
                  sText: price.toString() ?? '',
                  tText: 'ج.م',
                  colorstext4: true,
                  context: context),
              SizedBox(
                height: height * 0.09,
              ),
              SubTitel(
                  fText: 'SUB TOTAL',
                  sText: " ${price}",
                  tText: 'ج.م',
                  colorstext4: false,
                  context: context),
              SubTitel(
                  fText: 'TAX',
                  sText: " ${tax}",
                  tText: 'ج.م',
                  colorstext4: false,
                  context: context),
              SubTitel(
                  fText: 'Shipping Cost',
                  sText: " ${shipping_cost}",
                  tText: 'ج.م',
                  colorstext4: false,
                  context: context),
              SubTitel(
                  fText: 'DISCOUND',
                  sText: " ${coupon_discount}",
                  tText: 'ج.م',
                  colorstext4: false,
                  context: context),
              SubTitel(
                  fText: 'GRAND TOTAL',
                  sText: " ${grandTotal}",
                  tText: 'ج.م',
                  colorstext4: true,
                  context: context),
            ],
          ),
        ),
      ),
    );
  }

  Widget SubTitel(
      {colorstext4, String fText, String sText, String tText, context}) {
    return Text(
      fText ?? '' + sText ?? '' + tText ?? '',
      style: TextStyle(
        fontWeight: FontWeight.bold,
        color: colorstext4 ? Theme.of(context).primaryColor : Colors.black,
      ),
    );
  }

  Widget BuildRow({
    BuildContext context,
    String text1,
    String text2,
    String text3,
    String text4,
    bool colorstext2,
    bool colorstext4,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              text1,
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            Text(
              text2,
              style: TextStyle(
                fontWeight: colorstext4 ? FontWeight.w900 : FontWeight.w900,
                color:
                    colorstext2 ? Theme.of(context).primaryColor : Colors.grey,
              ),
            ),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              text3 ?? '',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            Text(
              text4 ?? '',
              style: TextStyle(
                fontWeight: colorstext4 ? FontWeight.w900 : FontWeight.w900,
                color:
                    colorstext4 ? Theme.of(context).primaryColor : Colors.grey,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
