import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/screens/outhantication/regist.dart';
import 'package:gomalgy/screens/outhantication/send_code.dart';

import 'package:gomalgy/widget/text_filed_outh.dart';
import 'package:gomalgy/providers/auth.dart';

class LoginScreen extends StatefulWidget {
  static String id = 'LoginScreen';
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> _globalKey = GlobalKey<FormState>();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String _email, _password;

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
        backgroundColor: Theme.of(context).primaryColor,
        body: Consumer(builder: (context, watch, child) {
          final authData = watch(authDataProvider);
          print("Log in Page  " + authData.isAuth.toString());
          if (!authData.isAuth) {
            return ListView(
              children: [
                Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 50),
                      child: Center(
                          child: Text(
                        'My Account',
                        style: TextStyle(color: Colors.white, fontSize: 20),
                      )),
                    ),
                    SizedBox(
                      height: 150,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          'SING IN',
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                      ],
                    ),
                  ],
                ),
                //*********************************************************** */
                Padding(
                  padding: const EdgeInsets.only(bottom: 0),
                  child: Stack(
                    children: [
                      Container(
                        height: MediaQuery.of(context).size.height * 0.67,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(color: Colors.black12, blurRadius: 5)
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                border: Border(
                                  left: BorderSide(
                                      color: Colors.indigo, width: 1),
                                  right: BorderSide(
                                      color: Colors.indigo, width: 1),
                                ),
                              ),
                              child: Form(
                                key: _globalKey,
                                child: Stack(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(top: 40.0),
                                      child: Column(
                                        children: [
                                          TextFieldsOuth(
                                            valed: (value) {
                                              if (value.isEmpty == true ||
                                                  value.contains(new RegExp(
                                                          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")) !=
                                                      true) {
                                                return "Please enter a vaild e-mail";
                                              }

                                              return '';
                                            },
                                            onClick: (value) {
                                              setState(() {
                                                _email = value;
                                              });
                                            },
                                            icon: Icons.email_outlined,
                                            hint: 'Enter Your email',
                                          ),
                                          TextFieldsOuth(
                                            valed: (value) {
                                              String pattern =
                                                  r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';
                                              RegExp regExp =
                                                  new RegExp(pattern);

                                              if (value.isEmpty == true) {
                                                return "Please Enter Your Password";
                                              } else if (value.length < 8) {
                                                return "Password should contain 8 characters at least.";
                                              } else if (regExp
                                                  .hasMatch(value)) {
                                                return "Password should contain 1 UPPERCASE,\n1 lowercase, 1 num6er and 1 special at least.";
                                              }
                                              return '';
                                            },
                                            onClick: (value) {
                                              setState(() {
                                                _password = value;
                                              });
                                              _password = value;
                                            },
                                            icon: Icons.lock,
                                            hint: 'Enter Your password',
                                          ),
                                          SizedBox(
                                            height: height * 0.04,
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 25, right: 25),
                                            child: Container(
                                              height: height * 0.06,
                                              child: ElevatedButton(
                                                  style:
                                                      ElevatedButton.styleFrom(
                                                    primary: Theme.of(context)
                                                        .primaryColor,
                                                    textStyle: TextStyle(
                                                        color: Colors.white),
                                                  ),
                                                  onPressed: () {
                                                    _validate(context);
                                                    print(_email +
                                                        ' ' +
                                                        _password);
                                                  },
                                                  child: Center(
                                                      child: Center(
                                                          child: Text(
                                                              'SING IN')))),
                                            ),
                                          ),
                                          SizedBox(
                                            height: height * 0.03,
                                          ),
                                          GestureDetector(
                                            onTap: () {
                                              Navigator.pushNamed(
                                                  context, SendCode.id);
                                            },
                                            child: Text(
                                              'Forgot Passwored',
                                              style: TextStyle(
                                                  color: Colors.red,
                                                  fontSize: 16),
                                            ),
                                          ),
                                          SizedBox(
                                            height: height * 0.03,
                                          ),
                                          GestureDetector(
                                            onTap: () {
                                              Navigator.pushNamed(
                                                  context, RegisterScreen.id);
                                            },
                                            child: Text(
                                              'No account yet Create one',
                                              style: TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 16),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              )),
                        ),
                      ),
                    ],
                    //==============================================================
                  ),
                ),
              ],
            );
          } else {
            return Container(
              child: null,
            );
          }
          //     Navigator.of(context).pop();
        }));
  }
//cheack validattion **********************************************************

  void _validate(BuildContext context) async {
    if (_globalKey.currentState.validate() == true) {
      _globalKey.currentState.save();
    }
  }
}
