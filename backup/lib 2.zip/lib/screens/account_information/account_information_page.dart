import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/helpers/base_url.dart' as baseurl;
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:gomalgy/providers/account_information.dart';

final nameController = TextEditingController();
final emailController = TextEditingController();
final addressController = TextEditingController();
final cityController = TextEditingController();
final postalCodeControlller = TextEditingController();
final countryControlller = TextEditingController();
final phoneControlller = TextEditingController();

/*
class AccountInformationPage extends StatefulWidget {
  @override
  _AccountInformationPageState createState() => _AccountInformationPageState();
}

class _AccountInformationPageState extends State<AccountInformationPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    context.read(accountDataProvider).getAccountInformation(UserId: '137');
    context
        .read(accountDataProvider)
        .getAccountInformationAddress(UserId: '137');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor,
        centerTitle: true,
        title: Text("Account Information"),
        leading: null,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: ShippingAddress(),
      ),
    );
  }

}
*/
class AccountInformationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    context.read(accountDataProvider).getAccountInformation(UserId: '137');
    context
        .read(accountDataProvider)
        .getAccountInformationAddress(UserId: '137');

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor,
        centerTitle: true,
        title: Text("Account Information"),
        leading: null,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: ShippingAddress(),
      ),
    );
  }
}

class ShippingAddress extends ConsumerWidget {
  @override
  Widget build(BuildContext context, ScopedReader watch) {
    //          print("add  ${accountInformationData.address[0].address}");
    //        print("code  ${accountInformationData.address[0].postalCode}");

    List<Widget> list = [];
    final accountInformationData = watch(accountDataProvider);
    list = List.from(
      accountInformationData.address.map((e) {
        return Container(
          padding: EdgeInsets.all(8),
          margin: EdgeInsets.only(bottom: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(e.addressdetails),
                  Text(e.city),
                  Text(e.postalCode),
                  Text(e.country),
                  Text(e.phone),
                ],
              ),
              PopupMenuButton(
                onSelected: (result) {
                  print("Deleted");
                  print(result);

                  context
                      .read(accountDataProvider)
                      .DeleteaccountInformationAddress(
                          Addressid: e.id.toString());
                },
                itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                  const PopupMenuItem(
                    value: 'result',
                    child: Text('Delete'),
                  ),
                ],
              ),
            ],
          ),
        );
      }),
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 20,
        ),
        Text(
          "Profile Information",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: 30,
        ),
        TextFiledBuilder(
          textEditingController: nameController,
          labletext: "Name",
          Value: accountInformationData.name,
          context: context,
          // getBalance(Userid: '137', databack: 'name').toString(),
        ),
        SizedBox(
          height: 30,
        ),
        TextFiledBuilder(
          labletext: "E-mail",
          Value: accountInformationData.email,
          textEditingController: emailController,
          context: context,
        ),
        SizedBox(
          height: 30,
        ),
        GestureDetector(
          onTap: () {
            context.read(accountDataProvider).changeAccountInformation(
                  name: nameController.text,
                );
          },
          child: Container(
            width: MediaQuery.of(context).size.width / 2.8,
            height: MediaQuery.of(context).size.height / 15,
            child: Center(
              child: Text(
                "Save Changes",
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
              ),
            ),
            color: Theme.of(context).primaryColor,
          ),
        ),
        SizedBox(
          height: 30,
        ),
        Text(
          "Shipping Information",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: 20,
        ),
        SizedBox(
          child: accountInformationData.address.length > 0
              ? Wrap(
                  children: list,
                )
              : Container(),
        ),
        SizedBox(
          height: 20,
        ),
        Center(
          child: IconButton(
            icon: Icon(
              Icons.add,
              size: 32,
            ),
            onPressed: () {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return Scaffold(
                    backgroundColor: Colors.transparent,
                    body: Center(
                        child: Container(
                      width: MediaQuery.of(context).size.width / 1.2,
                      height: MediaQuery.of(context).size.height / 1.8,
                      color: Colors.white,
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(
                              'Sipping Information',
                              style: TextStyle(
                                  fontSize:
                                      MediaQuery.of(context).textScaleFactor *
                                          14),
                            ),
                            TextFiledBuilder(
                              textEditingController: addressController,
                              Value: addressController.text,
                              labletext: 'Address',
                              context: context,
                            ),
                            TextFiledBuilder(
                              textEditingController: cityController,
                              // Value: '',
                              labletext: 'City',
                              context: context,
                            ),
                            TextFiledBuilder(
                              textEditingController: postalCodeControlller,
                              // Value: '',
                              labletext: 'Postal code',
                              context: context,
                            ),
                            TextFiledBuilder(
                              textEditingController: countryControlller,
                              //   Value: '',
                              labletext: 'Country',
                              context: context,
                            ),
                            TextFiledBuilder(
                              textEditingController: phoneControlller,
                              Value: phoneControlller.text,
                              labletext: 'Phone Number',
                              context: context,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                TextButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                    child: Text("Cancel")),
                                TextButton(
                                    onPressed: () {
                                      print(phoneControlller.text);
                                      if (phoneControlller.text != '' &&
                                          countryControlller.text != '' &&
                                          cityController.text != '' &&
                                          postalCodeControlller.text != '' &&
                                          addressController.text != '') {
                                        context
                                            .read(accountDataProvider)
                                            .addAddressAccountInformation(
                                              phone: phoneControlller.text,
                                              city: cityController.text,
                                              address: addressController.text,
                                              country: countryControlller.text,
                                              postal_code:
                                                  postalCodeControlller.text,
                                              user_id: '137',
                                            );

                                        print("in");
                                        Navigator.pop(context);
                                      } else {
                                        print("out");
                                      }
                                    },
                                    child: Text(
                                      "Save",
                                      style: TextStyle(
                                          color:
                                              Theme.of(context).primaryColor),
                                    )),
                              ],
                            ),
                          ],
                        ),
                      ),
                    )),
                  );
                },
              );
            },
          ),
        ),
        SizedBox(
          height: 20,
        ),
      ],
    );
  }

  Widget TextFiledBuilder(
      {String labletext,
      String Value,
      TextEditingController textEditingController,
      BuildContext context}) {
    textEditingController.text = Value;
    // print("val   $Value");

    return Center(
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[300],
          borderRadius: BorderRadius.all(Radius.circular(5)),
        ),
        width: MediaQuery.of(context).size.width / 1.1,
        child: TextField(
          keyboardType: TextInputType.emailAddress,
          enabled: labletext == "E-mail" ? false : true,
          //textDirection: TextDirection.rtl,
          onChanged: (value) {
            textEditingController.text = value;
          },
          decoration: InputDecoration(
            contentPadding: EdgeInsets.only(left: 10),
            focusColor: Theme.of(context).primaryColor,
            labelText: labletext,
            labelStyle: TextStyle(
              fontSize: MediaQuery.of(context).textScaleFactor * 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          controller: textEditingController,
          //textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
