import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/providers/auth.dart';
import 'package:gomalgy/providers/localization/app_language.dart';
import 'package:gomalgy/screens/account_information/account_information_page.dart';
import 'package:gomalgy/screens/naviation_bottom/warrantly.dart';
import 'package:gomalgy/screens/payment/purchase_history.dart';
import 'package:gomalgy/screens/wallet/Wallet_page.dart';
import 'package:url_launcher/url_launcher.dart';

class UserNav extends StatefulWidget {
  @override
  _UserNavState createState() => _UserNavState();
}

class _UserNavState extends State<UserNav> {
  String langType;
  final _url = 'https://gomlgy.com/shops/create';

  void _launchURL() async => await canLaunch(_url)
      ? await launch(_url)
      : throw 'Could not launch $_url';

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(6),
        height: MediaQuery.of(context).size.height - 180,
        child: ListView(
          children: [
            viewListTile(name: 'Wishlist', icon: Icons.thumb_up_alt_outlined),
            SizedBox(
              height: 10,
            ),
            viewListTile(
              name: 'Purchase History',
              icon: Icons.receipt_long_rounded,
              onpressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => PurchaseHistory()));
              },
            ),
            SizedBox(
              height: 10,
            ),
            viewListTile(
                name: 'My Wallet',
                icon: Icons.wallet_travel,
                onpressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => WalletPage()));
                }),
            SizedBox(
              height: 10,
            ),
            viewListTile(
              name: 'Account Information',
              icon: Icons.info_outline,
              onpressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => AccountInformationPage()));
              },
            ),
            SizedBox(
              height: 10,
            ),
            viewListTile(
              name: 'Warrantly',
              icon: Icons.person,
              onpressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                      builder: (context) => WarrantlyRequests('Warrantly')),
                );
              },
            ),
            SizedBox(
              height: 10,
            ),
            viewListTile(
                name: "Language",
                icon: Icons.language_outlined,
                onpressed: () {
                  showAlertDialog(context);
                }),
            SizedBox(
              height: 10,
            ),
            viewListTile(
                name: 'Join as a trader',
                icon: Icons.attach_money_outlined,
                onpressed: () {
                  print("Gooooooo");
                  _launchURL();
                }),
            SizedBox(
              height: 10,
            ),
            Consumer(builder: (ctx, watch, child) {
              var auth = watch(authDataProvider);
              print('Auth   ' + auth.isAuth.toString());
              return auth.isAuth
                  ? viewListTile(
                      name: 'Logout',
                      icon: Icons.logout,
                      onpressed: () {
                        context.read(authDataProvider).logout();
                      })
                  : Container();
            })
          ],
        ));
  }

  Widget viewListTile({String name, IconData icon, Function onpressed}) {
    return GestureDetector(
      onTap: onpressed,
      child: ListTile(
        title: Text(name),
        leading: Icon(icon),
        trailing: Icon(Icons.arrow_forward_ios),
      ),
    );
  } // end viewListTile()

  showAlertDialog(BuildContext context) {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Change Language",
        textAlign: TextAlign.center,
      ),
      actions: [
        Column(
          children: [
            TextButton(
              child: Text(
                "عربي",
                style: TextStyle(fontSize: 24),
                textAlign: TextAlign.center,
              ),
              onPressed: () {
                context
                    .read(appLanguageDataProvider)
                    .changeLanguage(Locale("ar"));
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text(
                "English",
                style: TextStyle(fontSize: 24),
                textAlign: TextAlign.center,
              ),
              onPressed: () {
                context
                    .read(appLanguageDataProvider)
                    .changeLanguage(Locale("en"));
                Navigator.of(context).pop();
              },
            ),
          ],
        )
      ],
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  } //  end showAlertDialog()
/*     showAlertDialog(BuildContext context) {
  // set up the AlertDialog
 // var model = AppLanguage().appLocal ;
  AlertDialog alert = AlertDialog(

    title: Text("Change Language"),
    actions: [
      Column(
        children: [
             RadioListTile(
        /* value: model,
        groupValue: appLocal, */
        value: 'عربي',
        groupValue: langType,
    title : Text("عربي" , style: TextStyle(fontSize: 24),),
    onChanged: (newValue) {
      //model = newValue ;
      context.read(appLanguageDataProvider).changeLanguage(Locale("ar"));
      Navigator.of(context).pop();
     },
  ) ,
   RadioListTile(
        /* value: model,
        groupValue: appLocal, */
        value: 'English',
        groupValue: langType,
    title : Text("English" , style: TextStyle(fontSize: 24),),
    onChanged: (newValue) {
      //model = newValue ;
      context.read(appLanguageDataProvider).changeLanguage(Locale("en"));
      Navigator.of(context).pop();
     },
  ) ,
        ],
      )
    ],
    elevation: 1,
    shape: RoundedRectangleBorder
    (borderRadius: BorderRadius.circular(20.0)
    ),
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
} //  end showAlertDialog() */
} // end class
