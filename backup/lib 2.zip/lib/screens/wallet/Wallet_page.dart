import 'dart:io';
import 'package:flutter/material.dart';
import 'package:gomalgy/helpers/base_url.dart' as baseurl;
import 'package:gomalgy/models/wallet_history_model.dart';
import 'package:gomalgy/widget/product_card/product_item_vertical.dart';
import 'package:gomalgy/widget/wallet_history_vertical.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class WalletPage extends StatefulWidget {
  @override
  _WalletPageState createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: null,
        backgroundColor: Theme.of(context).primaryColor,
        title: Text("My Wallet"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: ListView(
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height / 20,
              ),
              BalanceBuilderContainer(),
              SizedBox(
                height: MediaQuery.of(context).size.height / 14,
              ),
              Text(
                "Wallet Recharge History",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(
                height: 20,
              ),
              WalletHistortyBuilderContainer(),
              SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget BalanceBuilderContainer() {
    return FutureBuilder(
      future: getBalance(Userid: '137'),
      builder: (context, snaptshot) {
        if (snaptshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }

        //  print("Snap  ${snaptshot.data}");
        return Container(
          child: Column(
            children: [
              Text(
                "${double.parse((snaptshot.data).toString())} EG",
                style: TextStyle(
                  color: Theme.of(context).primaryColor,
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text("Wallet Balance"),
            ],
          ),
        );
      },
    );
  }

  Widget WalletHistortyBuilderContainer() {
    return FutureBuilder<List<WalletHistoryModel>>(
      future: getWalletHistory(Userid: '137'),
      builder: (context, snaptshot) {
        if (snaptshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }

        //  print("SnapARR  ${snaptshot.data}");
        List<Widget> list = [];
        list = List.from(snaptshot.data.map((e) {
          return WalletHistoryVertical(
            methodname: e.paymentMethod,
            Price: e.amount,
            approvalname: e.approval,
          );
        }));

        return Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          color: Colors.white,
          child: Wrap(
            children: list,
          ),
        );
      },
    );
  }

// 137
  Future<List<WalletHistoryModel>> getWalletHistory({String Userid}) async {
    final url = baseurl.Urls.api + '/wallet/history/' + Userid;
    //print(url);
    // print(email);
    // print(password);

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: Map<String, String>.from({
          //    'Content-Type': 'application/json',
          'Authorization':
              'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjI3MDRlMWYwODIxMDk3ODIyYjMzMDM4NzM0MGE2MDJkNzgxM2RiYWJhMmViZmY1NGIyMDM5NmRlYzg2N2Y4ZTdkZTg0MDNjNzJjZTEyNGE1In0.eyJhdWQiOiIzIiwianRpIjoiMjcwNGUxZjA4MjEwOTc4MjJiMzMwMzg3MzQwYTYwMmQ3ODEzZGJhYmEyZWJmZjU0YjIwMzk2ZGVjODY3ZjhlN2RlODQwM2M3MmNlMTI0YTUiLCJpYXQiOjE2MTc4NzM4MDIsIm5iZiI6MTYxNzg3MzgwMiwiZXhwIjoxNjQ5NDA5ODAyLCJzdWIiOiIxMzciLCJzY29wZXMiOltdfQ.XH6HpOMbSPPogkHHMMYUItf_0T3NactuHLgGQCM7GVUModItAUvj1I8BPBFt3Q3wvNiRwp9xQBHL6TZL9Lq_BSeYTvXt8X2jYbBWHvfeYr3s1486b88f06WFYC7AGP3bXgsxs0zEEholZy20hNMeM4tP29ZR2nnpXIKkIV7JS1aUOqYqLoa3dLfBsQf3KSV9m30CNckLHVwItBZJXynNTcTURAWEDuBoLboqFj1qRcIJvVarSxPisPIKL1S9XkfRYENekMPt3d7uN9AJX7jrE-SoioQ3CPoqxo-ZA88J7MEL2OZjJjXqK6aOEFViN3mBfHSsF4K5gMgRP32q56w8AZ1_907iDGDyq36XeKt_EiAgePsFfLwVVkdn0ZYI8juOM95MadwZHx6EdXbQeX5cHhNerxS61ot-mCeGrIKCFJ-9aGuQz3WIU4FH5-hzqVIxE2BfPcQZ8pj3HyPlGj7zd0puN5ybXjYdI_A4gCQu9M7aTSsa3jWXllALIAQGnRSLggfSkL5CwkiIOWQRG2p_81Z-gA-USoLwG206sFNlo9uoIG31l3dWVXPAiwrIhjGCnyg-XFBFO8H_a8iqUgADQq4IjspcZzIlLKIKDdxKD0p3GDrg77UnudbcW8-2PBGSIxhvkF6gu0VC80pjR4kxXMjPwfAQcSBH01jrSe3F_eo'
        }),
      );
      // print("URLHIStory wallet   : " + url.toString());
      // print("Response HIStory wallet  " + response.body.toString());
      final responseData = json.decode(response.body);
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        print(response.body);
        throw HttpException('An Error occurred!');
      }

      //print("SSSSSSSSSSS    " + responseData['balance'].toString());
      var data = (responseData['data'] as List).map((data) {
        final extractedData = data as Map<String, dynamic>;

        // print((extractedData['amount']));
        // print((extractedData['approval']));
        // print((extractedData['payment_method']));

        return WalletHistoryModel(
          amount: int.parse(extractedData['amount'].toString()),
          approval: extractedData['approval'].toString(),
          paymentMethod: extractedData['payment_method'].toString(),
        );
      }).toList();
      return data;
    } catch (e) {
      print("E  " + e);
      throw e;
    }
  }

  Future<dynamic> getBalance({String Userid}) async {
    final url = baseurl.Urls.api + '/wallet/balance/' + Userid;
    //  print(url);
    // print(email);
    // print(password);

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: Map<String, String>.from({
          'Content-Type': 'application/json',
          'Authorization':
              'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjMyZmFkYjhiZjAyNTAyZmQzMzY2NWNmOWQ5NzRjYzMyNGE2NThmMDljYmM1MDdiYTk5ODJjODM1YjU5YmI4YzMxMTY1MWUyNmIzNGM2OTJmIn0.eyJhdWQiOiIzIiwianRpIjoiMzJmYWRiOGJmMDI1MDJmZDMzNjY1Y2Y5ZDk3NGNjMzI0YTY1OGYwOWNiYzUwN2JhOTk4MmM4MzViNTliYjhjMzExNjUxZTI2YjM0YzY5MmYiLCJpYXQiOjE2MTc3MDY4MTIsIm5iZiI6MTYxNzcwNjgxMiwiZXhwIjoxNjQ5MjQyODEyLCJzdWIiOiIxNjMiLCJzY29wZXMiOltdfQ.mccdVavA4r5OJxbTHZRelFzHsrVeU_6GbJd3RR_4fOBM1a8VvP-jTa2F0QRpPqAKsyVgV-hluULSajchChCPwXPaGWsWTyBReCOk5ugEi_5T0vuGXWkCDKEcAAdQc_WBwJXbCRamfbAuYG_5NP81urZXpYWM5p9WZJ7JahiS3js8fgWfHvYu_yCBHZ10SAtU56V_ujLSFOkhMWcQCi8IjPFlKQzoqNSNy2iMgXwACQjKDzi31jd46toWh9dv4DSZSwcaoyyW0ziNpJojFM2Vy207F7ofzYGAHbiinGeZq_RH6898hOAeDSFaYFGAqP5-GM87TCniKEZiIH9d2ul45YEvT7m4nJ2FksS3nnMnkT88bkQyONuOGWJzsNlnsPVzCH1xxmy0KMUXItOYdncfr0PqpZz9bFjjRNemUmm0SRVqxDR7CIJHk9cxUyet7VmgQRxJesZOM2L2rh4O-T9OKz4pAMjyT1jeRDzWcVfwH3xnnMr-kt6ohUYlUtrCHfLQZUaoWTfmaEgFKOaHQ4JgvFemnKhLtmzko4Yi9svyYNrE-U3gZsR_Lbp9vNjrx57v83DGnKSUeV0e7PXKSuSt87qIBnOLapNeocrWZlDgT1inIBSHF8s0mSqu17JkgQg_u-YA5wYagSa4hVdbSjk32B_WWMC7zJQQ2hseacNKOqc'
        }),
      );
      //  print("URL   : " + url.toString());
      // print("Response1  " + response.body.toString());
      final responseData = json.decode(response.body);
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        print(response.body);
        throw HttpException('An Error occurred!');
      }

      //print("SSSSSSSSSSS    " + responseData['balance'].toString());
      return responseData['balance'];
    } catch (e) {
      print("E  " + e);
      throw e;
    }
  }
}
