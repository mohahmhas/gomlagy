import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gomalgy/widget/text_copon.dart';

class CardPayment extends StatefulWidget {
  static String id = 'CardPayment';

  @override
  _CardPaymentState createState() => _CardPaymentState();
}

class _CardPaymentState extends State<CardPayment> {
  @override
  Widget build(BuildContext context) {
    int flexNUm, flexBrith, flexCvc;

    funNUmber() {
      setState(() {
        flexNUm = 3;
        flexBrith = 1;
        flexCvc = 0;
      });
    }

    funBirth() {
      setState(() {
        flexNUm = 1;
        flexBrith = 1;
        flexCvc = 1;
      });
    }
    // alart() {
    //   showAlertDialog(BuildContext context) {
    //     // set up the buttons
    //     Widget cancelButton = TextButton(
    //       child: Text("Cancel"),
    //       onPressed: () {},
    //     );
    //     Widget continueButton = TextButton(
    //       child: Text("Continue"),
    //       onPressed: () {},
    //     );

    //     // set up the AlertDialog
    //     AlertDialog alert = AlertDialog(
    //       title: Text("AlertDialog"),
    //       content: Text(
    //           "Would you like to continue learning how to use Flutter alerts?"),
    //       actions: [
    //         cancelButton,
    //         continueButton,
    //       ],
    //     );

    //     // show the dialog
    //     showDialog(
    //       context: context,
    //       builder: (BuildContext context) {
    //         return alert;
    //       },
    //     );
    //   }
    // }

    return Scaffold(
      appBar: AppBar(
        title: Text('Card Payment'),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 10, left: 5),
        child: Column(
          children: [
            Container(
              color: Colors.orange[900],
              width: MediaQuery.of(context).size.width * 0.95,
              height: MediaQuery.of(context).size.height * 0.25,
              child: Column(
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'SUB TOTAL',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                              Text(
                                '57.0',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'TAX',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                              Text(
                                '3.0',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Shipping Cost',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                              Text(
                                '90.0',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'COUPON Discount',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                              Text(
                                '0.0',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'GRAND TOTAL',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                              Text(
                                '150',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Center(
                child: Text(
              'Enter your Credit or debit Card inform to \n complete the checkout and place order',
              style: TextStyle(color: Colors.black, fontSize: 16),
            )),
            SizedBox(
              height: 15,
            ),
            Container(
                color: Colors.grey[300],
                width: MediaQuery.of(context).size.width * 0.95,
                height: 50,
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: funNUmber,
                      child: Expanded(
                        flex: flexNUm,
                        child: TextFieldsCopon(
                          hint: '1234  1234  1234 1234 ',
                          icon: Icons.view_stream_rounded,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: funBirth,
                      child: Expanded(
                        flex: flexBrith,
                        child: TextFieldsCopon(
                          hint: ' MM/YY',
                        ),
                      ),
                    ),
                    Expanded(
                      flex: flexCvc,
                      child: TextFieldsCopon(
                        hint: ' CVC',
                      ),
                    ),
                  ],
                )),
            SizedBox(
              height: 15,
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.95,
              height: 50,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Theme.of(context).primaryColor,
                  ),
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (c) => AlertDialog(
                              title: Row(
                                children: [
                                  CircularProgressIndicator(),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 8.0),
                                    child: Text(
                                      'Please wait.Your Transaction is \n Processing',
                                      style: TextStyle(
                                          color: Colors.grey, fontSize: 15),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        barrierDismissible: false);
                    // CupertinoAlertDialog(
                    //   title: Text('dasdaw'),
                    //   content: Text('safefaefadfgesrhgdn'),
                    //   actions: [
                    //     CupertinoDialogAction(
                    //         child: TextButton(
                    //       onPressed: () {},
                    //       child: Text('ok'),
                    //     ))
                    //   ],
                    // );
                  },
                  child: Text('CONFIRM PAYMENT')),
            )
          ],
        ),
      ),
    );
  }
}
