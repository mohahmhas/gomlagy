import 'dart:convert';
import 'package:gomalgy/helpers/base_url.dart' as baseurl;
import 'package:gomalgy/helpers/http_exception.dart';
import 'package:gomalgy/models/history_model.dart';
import 'package:http/http.dart' as http;

class PurchasesHistory {
  Future<List> fetchPurchaseHistory() async {
    var url = baseurl.Urls.api + '/purchase-history/137';

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: Map<String, String>.from({
          'Content-Type': 'application/json',
          'Authorization':
              'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjMyZmFkYjhiZjAyNTAyZmQzMzY2NWNmOWQ5NzRjYzMyNGE2NThmMDljYmM1MDdiYTk5ODJjODM1YjU5YmI4YzMxMTY1MWUyNmIzNGM2OTJmIn0.eyJhdWQiOiIzIiwianRpIjoiMzJmYWRiOGJmMDI1MDJmZDMzNjY1Y2Y5ZDk3NGNjMzI0YTY1OGYwOWNiYzUwN2JhOTk4MmM4MzViNTliYjhjMzExNjUxZTI2YjM0YzY5MmYiLCJpYXQiOjE2MTc3MDY4MTIsIm5iZiI6MTYxNzcwNjgxMiwiZXhwIjoxNjQ5MjQyODEyLCJzdWIiOiIxNjMiLCJzY29wZXMiOltdfQ.mccdVavA4r5OJxbTHZRelFzHsrVeU_6GbJd3RR_4fOBM1a8VvP-jTa2F0QRpPqAKsyVgV-hluULSajchChCPwXPaGWsWTyBReCOk5ugEi_5T0vuGXWkCDKEcAAdQc_WBwJXbCRamfbAuYG_5NP81urZXpYWM5p9WZJ7JahiS3js8fgWfHvYu_yCBHZ10SAtU56V_ujLSFOkhMWcQCi8IjPFlKQzoqNSNy2iMgXwACQjKDzi31jd46toWh9dv4DSZSwcaoyyW0ziNpJojFM2Vy207F7ofzYGAHbiinGeZq_RH6898hOAeDSFaYFGAqP5-GM87TCniKEZiIH9d2ul45YEvT7m4nJ2FksS3nnMnkT88bkQyONuOGWJzsNlnsPVzCH1xxmy0KMUXItOYdncfr0PqpZz9bFjjRNemUmm0SRVqxDR7CIJHk9cxUyet7VmgQRxJesZOM2L2rh4O-T9OKz4pAMjyT1jeRDzWcVfwH3xnnMr-kt6ohUYlUtrCHfLQZUaoWTfmaEgFKOaHQ4JgvFemnKhLtmzko4Yi9svyYNrE-U3gZsR_Lbp9vNjrx57v83DGnKSUeV0e7PXKSuSt87qIBnOLapNeocrWZlDgT1inIBSHF8s0mSqu17JkgQg_u-YA5wYagSa4hVdbSjk32B_WWMC7zJQQ2hseacNKOqc'
        }),
      );

      final extractedData = json.decode(response.body) as Map<String, dynamic>;
      // print(response.body);
      if (response.statusCode >= 400) {
        throw HttpException('An error occurred');
      }
      if (extractedData == null) {
        return [];
      }

      var data = (extractedData['data'] as List).map((data) {
        final extractedData = data as Map<String, dynamic>;

        return HistoryModel(
          code: extractedData['code'],
          date: extractedData['date'],
          paymentStatus: extractedData['payment_status'],
          grandTotal: double.parse(extractedData['grand_total'].toString()),
          address: extractedData['shipping_address']['address'],
          city: extractedData['shipping_address']['city'],
          country: extractedData['shipping_address']['country'],
          link: extractedData['links']["details"],
        );
      }).toList();

      return data;
    } catch (e) {
      throw HttpException('An error occurred');
    }
  }
}
