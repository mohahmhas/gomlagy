import 'package:flutter/material.dart';

class WalletHistoryVertical extends StatelessWidget {
  final String methodname;
  final String approvalname;
  final int Price;

  WalletHistoryVertical({this.methodname, this.approvalname, this.Price});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(8),
      child: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Amount",
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                "$Price " + ".ج.م",
                style: TextStyle(
                    color: Theme.of(context).primaryColor,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
          Row(
            //mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Method:  ",
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(methodname,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                  )),
            ],
          ),
          Row(
            //mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Approval:  ",
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                approvalname,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          Divider(
            color: Colors.grey,
            thickness: 1.5,
          ),
          SizedBox(
            height: 10,
          ),
        ],
      ),
    );
  }
}
