class ProductDetailsList {
  String nameProduct;
  String namemodel;
  int numofquantity;
  var color;

  ProductDetailsList(
      {this.nameProduct, this.namemodel, this.numofquantity, this.color});
}
