class WalletHistoryModel {
  WalletHistoryModel({
    this.amount,
    this.paymentMethod,
    this.approval,
  });

  final int amount;
  final String paymentMethod;
  final String approval;
}
