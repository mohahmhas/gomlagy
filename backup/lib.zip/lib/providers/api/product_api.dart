import 'dart:convert';
import 'package:gomalgy/helpers/base_url.dart';
import 'package:gomalgy/models/product_categories_model.dart';
import 'package:gomalgy/models/subProduct_categories_model.dart';
import 'package:http/http.dart';

abstract class CategoriesApi {
  //static List<dynamic> list = [] ;
  //static int lengthOfList ;

  static Future<List<CategoriesData>> getCategoriesNames(
      String endPoint) async {
    final Response response = await get(Uri.parse(Urls.api + endPoint));
    try {
      if (response.statusCode == 200) {
        // parsing json into List of objects
        final parsed = json.decode(response.body).cast<String, dynamic>();
        return parsed['data']
            .map<CategoriesData>((item) => CategoriesData.fromJson(item))
            .toList();
      }
    } catch (e) {
      print(e);
    }
    return null;
  } // end getCategoriesNames()

  static Future<List<Products>> getSubCategoriesData(
      String endPoint, int index) async {
    final Response response = await get(Uri.parse(Urls.api + endPoint));
    // print('Response $response');
    try {
      if (response.statusCode == 200) {
        // parsing json into List of objects
        final parsed = json.decode(response.body).cast<String, dynamic>();
        // list = parsed['data'] ;
        //  lengthOfList = list.length ;
        //  print('list = $lengthOfList');
        return parsed['data'][index]['products']
            .map<Products>((item) => Products.fromJson(item))
            .toList();
      }
    } catch (e) {
      print(e);
    }
    return null;
  }
  // end getCategoriesNames()
  /*  static Stream<List<Products>> getSubCategoriesData(String endPoint ) async* {

      final Response response = await get(Urls.api+endPoint);
     // print('Response $response');
      try {
        if(response.statusCode == 200){
          // parsing json into List of objects
          final parsed = json.decode(response.body).cast<String , dynamic>();
          list = parsed['data'] ;
          print('list = $list');
         for(int x = 0 ; x < list.length ; x++ ){
           yield  parsed['data'][x]['products'].map<Products>((item) => Products.fromJson(item)).toList();
         }

        }
      } catch (e) {
             print( e);
      }

  } // end getCategoriesNames() */

} // end class
