import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/providers/home_categories.dart' as homeCat;
import 'package:gomalgy/widget/home_category_widgets/image_slider_first_item.dart';

class SeeAllProducts extends StatefulWidget {
  final appBarName ;
  SeeAllProducts({this.appBarName});
  @override
  _SeeAllProductsState createState() => _SeeAllProductsState();
}

class _SeeAllProductsState extends State<SeeAllProducts> {

   final imageSlider = ChangeNotifierProvider<homeCat.ImagesSlider>((ref) {
  return homeCat.ImagesSlider();
});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.orange[900],
        title: Text(widget.appBarName),
      ),
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SliderWidget(
                    sliderDataProvider: imageSlider,
                    url: '/offers',
                  ),
          ],
        ),
      ),
    );
  }
}