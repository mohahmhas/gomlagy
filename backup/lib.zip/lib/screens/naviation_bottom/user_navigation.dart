import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/providers/auth.dart';

class UserNav extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(6),
        height: MediaQuery.of(context).size.height - 180,
        child: ListView(
          children: [
            viewListTile(name: 'Wishlist', icon: Icons.thumb_up_alt_outlined),
            SizedBox(
              height: 10,
            ),
            viewListTile(
                name: 'Purchase History', icon: Icons.receipt_long_rounded),
            SizedBox(
              height: 10,
            ),
            viewListTile(name: 'My Wallet', icon: Icons.wallet_travel),
            SizedBox(
              height: 10,
            ),
            viewListTile(name: 'Account Information', icon: Icons.info_outline),
            SizedBox(
              height: 10,
            ),
            viewListTile(name: 'Warrantly', icon: Icons.person),
            SizedBox(
              height: 10,
            ),
            viewListTile(name: "Language", icon: Icons.language_outlined),
            SizedBox(
              height: 10,
            ),
            viewListTile(
                name: 'Join as a trader', icon: Icons.attach_money_outlined),
            SizedBox(
              height: 10,
            ),
            Consumer(builder: (ctx, watch, child) {
              var auth = watch(authDataProvider);
              print('Auth   ' + auth.isAuth.toString());
              return auth.isAuth
                  ? viewListTile(
                      name: 'Logout',
                      icon: Icons.logout,
                      onpressed: () {
                        context.read(authDataProvider).logout();
                      })
                  : Container();
            })
          ],
        ));
  }

  Widget viewListTile({String name, IconData icon, Function onpressed}) {
    return GestureDetector(
      onTap: onpressed,
      child: ListTile(
        title: Text(name),
        leading: Icon(icon),
        trailing: Icon(Icons.arrow_forward_ios),
      ),
    );
  }
}
