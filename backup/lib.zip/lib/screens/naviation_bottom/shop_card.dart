import 'package:flutter/material.dart';
import 'package:gomalgy/screens/payment/fatwora.dart';

class ShopCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Container(
      color: Colors.red,
      child: MaterialButton(
        onPressed: () {
          Navigator.push(
              (context), MaterialPageRoute(builder: (context) => Fatwora()));
        },
        child: Text("Pressed"),
        height: 50,
      ),
    ));
  }
}
