import 'package:flutter/material.dart';
import 'package:gomalgy/screens/payment/card_Payment.dart';
import 'package:gomalgy/screens/payment/purchase_history.dart';
import 'package:gomalgy/widget/shop_card/custom_payment_widget.dart';
import 'package:gomalgy/widget/text_copon.dart';
import 'package:url_launcher/url_launcher.dart';

enum PaymentWays { paypal, visa, wallet, cash }

class CheckOut extends StatefulWidget {
  static String id = 'CheckOut';

  @override
  _CheckOutState createState() => _CheckOutState();
}

class _CheckOutState extends State<CheckOut> {
  Map<PaymentWays, bool> checked = {
    PaymentWays.cash: false,
    PaymentWays.paypal: false,
    PaymentWays.visa: false,
    PaymentWays.wallet: false,
  };

  @override
  Widget build(BuildContext context) {
    CustomPaymentWidget www = CustomPaymentWidget();
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    Function stState() {
      setState(() {});
    }

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Checkout',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Stack(
        children: [
          ListView(children: [
            Column(
              children: [
                CustomPaymentWidget(
                  image: 'assets/paypal_logo_png_7.png',
                  text: 'Checkout With Paypal',
                  id: PaymentWays.paypal,
                  checked: checked,
                  ststate: stState,
                ),
                CustomPaymentWidget(
                  image: 'assets/cardpayment.png',
                  text: 'Checkout With Card',
                  id: PaymentWays.visa,
                  ststate: stState,
                  checked: checked,
                ),
                CustomPaymentWidget(
                  image: 'assets/cod.png',
                  text: 'Cach on Delivery',
                  id: PaymentWays.cash,
                  ststate: stState,
                  checked: checked,
                ),
                CustomPaymentWidget(
                  image: 'assets/paypal_logo_png_7.png',
                  text: 'Wallet Balance',
                  id: PaymentWays.wallet,
                  ststate: stState,
                  checked: checked,
                ),
              ],
            ),
          ]),
          Positioned(
            left: 0,
            bottom: 70,
            child: Column(
              children: [
                Row(
                  children: [
                    TextFieldsCopon(
                      hint: 'Coupon Code',
                    ),
                    Container(
                      height: 50,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Theme.of(context).primaryColor,
                          ),
                          onPressed: () {
                            PaymentWays selectedWay;
                            checked.forEach((k, v) {
                              if (v == true) {
                                selectedWay = k;
                              }
                            });

                            _nav(selectedWay);
                            // print(selectedWay);
                          },
                          child: Text('Apply Order')),
                    ),
                  ],
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Total Amount',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '150.00' + 'ج م',
                        style: TextStyle(
                            color: Colors.red, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 0,
            child: Container(
              width: width,
              height: height * 0.06,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Theme.of(context).primaryColor,
                  ),
                  onPressed: () {
                    PaymentWays selectedWay;
                    checked.forEach((k, v) {
                      if (v == true) {
                        selectedWay = k;
                      }
                    });

                    _nav(selectedWay);
                    // print(selectedWay);
                  },
                  child: Text('PROCEED TO CHECKOUT')),
            ),
          ),
        ],
      ),
    );
  }

  _nav(selectedWay) {
    switch (selectedWay) {
      case PaymentWays.cash:
        return Navigator.pushNamed(context, CheckOut.id);

      case PaymentWays.paypal:
        return openUrl(
            url:
                'https://www.google.com/search?q=riverpod&authuser=0&sxsrf=ALeKk01B8lsCJkfigMF5PzJ-mYWnmyNx0g%3A1617639039850&source=hp&ei=fzZrYIPPMfTOgwft-4PIDA&iflsig=AINFCbYAAAAAYGtEj_w90-UaywDGbYQTAPQ31qTLyBei&oq=&gs_lcp=Cgdnd3Mtd2l6EAEYAzIHCCMQ6gIQJzIHCC4Q6gIQJzIHCCMQ6gIQJzIHCCMQ6gIQJzIHCCMQ6gIQJzIJCCMQ6gIQJxATMgkIIxDqAhAnEBMyBwgjEOoCECcyCQgjEOoCECcQEzIHCCMQ6gIQJ1AAWABgoCBoAXAAeACAAQCIAQCSAQCYAQCqAQdnd3Mtd2l6sAEK&sclient=gws-wiz');

      case PaymentWays.visa:
        return Navigator.pushNamed(context, CardPayment.id);
      case PaymentWays.cash:
        return Navigator.pushNamed(context, PurchaseHistory.id);
      case PaymentWays.wallet:
        return Navigator.pushNamed(context, PurchaseHistory.id);
    }
  }

  static Future openUrl({String url}) async {
    if (url.trim().isEmpty) {
      await _openUrl('http://google.com');
    } else {
      await _openUrl('http:$url.com');
    }
  }

  static Future _openUrl(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    }
  }
}
