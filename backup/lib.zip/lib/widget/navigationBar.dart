import 'package:flutter/material.dart';
import 'package:curved_bottom_navigation/curved_bottom_navigation.dart';
import 'package:gomalgy/screens/naviation_bottom/Search_all_products.dart';
import 'package:gomalgy/screens/naviation_bottom/all_products.dart';
import 'package:gomalgy/screens/naviation_bottom/home.dart';
import 'package:gomalgy/screens/naviation_bottom/shop_card.dart';
import 'package:gomalgy/screens/naviation_bottom/user_navigation.dart';
import 'package:gomalgy/widget/text_fields.dart';
import 'package:gomalgy/widget/drawer.dart';

class Navigat extends StatefulWidget {
  @override
  _NavigatState createState() => _NavigatState();
}

class _NavigatState extends State<Navigat> {
  var navPos = 0;

  @override
  Widget build(BuildContext context) {
    void changeToSearchPage() {
      if (navPos == 2) {
        return;
      }
      setState(() {
        navPos = 2;
        print(navPos);
      });
    }

    final GlobalKey<ScaffoldState> drawerKey = GlobalKey<ScaffoldState>();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor,
        title: Padding(
          padding: const EdgeInsets.only(top: 20, bottom: 15),
          child: Image.asset(
            'assets/gomlgy_logo.png',
            scale: 5,
          ),
        ),
        centerTitle: true,
        leading: null,
        actions: [
          IconButton(
              icon: Icon(
                Icons.shopping_cart_outlined,
                color: Colors.white,
              ),
              onPressed: () {
                //      Navigator.pushNamed(context, );
              }),
        ],
        bottom: PreferredSize(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: TextFields(
              icon: Icons.search,
              hint: 'what are you looking for?',
              onTap: changeToSearchPage,
            ),
          ),
          preferredSize: Size.fromHeight(80),
        ),
      ),
      key: drawerKey,
      drawer: CustomDrawer(),
      body: Stack(children: [
        //  CustomAppBar(drawerKey: drawerKey),
        IndexedStack(
          index: navPos,
          children: [
            Home(),
            AllProducts(),
            SearchAllProducts(),
            ShopCard(),
            UserNav(),
          ],
        ),
        Align(
            alignment: Alignment.bottomCenter,
            child: CurvedBottomNavigation(
              navHeight: 50,
              fabSize: 50,
              bgColor: Theme.of(context).primaryColor,
              fabBgColor: Theme.of(context).primaryColor,
              selected: navPos,
              onItemClick: (i) {
                setState(() {
                  navPos = i;
                });
              },
              items: [
                Icon(Icons.home, color: Colors.white),
                Icon(Icons.view_module_rounded, color: Colors.white),
                Icon(Icons.search, color: Colors.white),
                Icon(Icons.shopping_cart, color: Colors.white),
                Icon(Icons.account_circle_sharp, color: Colors.white),
              ],
            ))
      ]),
    );
  }
}
