import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/mainPage.dart';

import 'package:gomalgy/screens/outhantication/log_screen.dart';
import 'package:gomalgy/screens/outhantication/regist.dart';
import 'package:gomalgy/screens/outhantication/send_code.dart';
import 'package:gomalgy/screens/payment/card_Payment.dart';
import 'package:gomalgy/screens/payment/checkout.dart';
import 'package:gomalgy/screens/payment/purchase_history.dart';
import 'package:splashscreen/splashscreen.dart';
import './providers/auth.dart';

//wellcom
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return ProviderScope(
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primaryColor: Colors.orange[900],
        ),
        routes: {
          LoginScreen.id: (context) => LoginScreen(),
          RegisterScreen.id: (context) => RegisterScreen(),
          SendCode.id: (context) => SendCode(),
          CheckOut.id: (context) => CheckOut(),
          CardPayment.id: (context) => CardPayment(),
          PurchaseHistory.id: (context) => PurchaseHistory(),
          MainPgae.id: (context) => MainPgae()
        },
        home: SplashWidget(),
      ),
    );
  }
}

class SplashWidget extends StatelessWidget {
  const SplashWidget({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Future<Widget> loadFromFuture() async {
      context.read(authDataProvider).tryAutoSignin();
      //  print(result);
      print('result');

      // <fetch data from server. ex. login>

      return Future.value(new MainPgae());
    }

    return SplashScreen(
      navigateAfterFuture: loadFromFuture(),
      //routeName: MainPgae.id,
      photoSize: 100,
      image: Image.asset("assets/logo_o_foreground.png"),
      // text: "Normal Text",
      //  textType: TextType.NormalText,

      backgroundColor: Color(0xffeb6824),
    );
  }
}
