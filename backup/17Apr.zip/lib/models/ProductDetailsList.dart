import 'package:flutter/cupertino.dart';

class ProductDetailsList {
  String nameProduct;
  String namemodel;
  int numofquantity;
  String userid;
  String productid;
  var color;

  ProductDetailsList(
      {this.nameProduct,
      this.namemodel,
      this.numofquantity,
      this.color,
      this.productid,
      this.userid});
}
