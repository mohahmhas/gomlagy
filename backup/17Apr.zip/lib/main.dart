import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/mainPage.dart';
import 'package:gomalgy/providers/localization/app_localizations.dart';
import 'package:gomalgy/screens/account_information/account_information_page.dart';
import 'package:gomalgy/screens/my_wishlist_screen.dart';

import 'package:gomalgy/screens/outhantication/log_screen.dart';
import 'package:gomalgy/screens/outhantication/regist.dart';
import 'package:gomalgy/screens/outhantication/send_code.dart';
import 'package:gomalgy/screens/payment/card_Payment.dart';
import 'package:gomalgy/screens/payment/checkout.dart';
import 'package:gomalgy/screens/payment/purchase_history.dart';
import 'package:gomalgy/screens/wallet/Wallet_page.dart';
import 'package:splashscreen/splashscreen.dart';
import './providers/auth.dart';
import './providers/localization/app_language.dart';
import 'helpers/keys.dart';

//wellcom
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  AppLanguage appLanguage = AppLanguage();
  await appLanguage.fetchLocale();
  runApp(MyApp(
    appLanguage: appLanguage,
  ));
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  final AppLanguage appLanguage;

  MyApp({this.appLanguage});
  bool firstLoad = true;
  @override
  Widget build(BuildContext context) {
    return ProviderScope(child: Consumer(
      builder: (ctx, watch, child) {
        /////////////////////////////////////////////////////////
        final model = watch(appLanguageDataProvider);
        firstLoad = false;

        return MaterialApp(
          navigatorKey: Keys.navKey,
          locale: firstLoad ? appLanguage.appLocal : model.appLocal,
          supportedLocales: [
            Locale('en', 'US'),
            Locale('ar', ''),
          ],
          localizationsDelegates: [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
          ],
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            primaryColor: Colors.orange[900],
          ),
          routes: {
            LoginScreen.id: (context) => LoginScreen(),
            RegisterScreen.id: (context) => RegisterScreen(),
            SendCode.id: (context) => SendCode(),
            CheckOut.id: (context) => CheckOut(),
            CardPayment.id: (context) => CardPayment(),
            PurchaseHistory.id: (context) => PurchaseHistory(),
            MainPgae.id: (context) => MainPgae(),
            MyWishListScreen.id: (context) => MyWishListScreen(),
            WalletPage.id: (context) => WalletPage(),
            AccountInformationPage.id: (context) => AccountInformationPage(),
          },
          home: SplashWidget(),
        );
      },
    ));
  }
}

class SplashWidget extends StatelessWidget {
  const SplashWidget({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Future<Widget> loadFromFuture() async {
      context.read(authDataProvider).tryAutoSignin();
      //  print(result);
      print('result');

      // <fetch data from server. ex. login>

      return Future.value(new MainPgae());
    }

    return SplashScreen(
      navigateAfterFuture: loadFromFuture(),
      //routeName: MainPgae.id,
      photoSize: 100,
      image: Image.asset("assets/logo_o_foreground.png"),
      // text: "Normal Text",
      //  textType: TextType.NormalText,

      backgroundColor: Color(0xffeb6824),
    );
  }
}
