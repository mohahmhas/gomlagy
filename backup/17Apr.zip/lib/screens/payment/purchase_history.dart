import 'package:flutter/material.dart';

class PurchaseHistory extends StatelessWidget {
  static String id = 'PurchaseHistory';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Purchase History'),
      ),
    );
  }
}
