import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/models/cart_items.dart';
import '../helpers/base_url.dart' as baseurl;
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../helpers/http_exception.dart';

final CartItemDataProvider = ChangeNotifierProvider<ShopCartProvider>((ref) {
  return ShopCartProvider();
});

class ShopCartProvider extends ChangeNotifier {
  List<CartItem> _ListProductCartItem = [];
  double _TotalPrice = 0;
  double _TotalPriceShipping = 0;
  List<CartItem> get GetListProductCartItem => _ListProductCartItem;

  double get TotalPrice => _TotalPrice;
  double get TotalPriceShipping => _TotalPriceShipping;

  int CalcTotal() {
    int totalprice = 0;
    //print("length  ${_ListProductCartItem.length}");
    _TotalPriceShipping = 0;
    for (int index = 0; index < _ListProductCartItem.length; index++) {
      // print("in For Loop ");
      totalprice += ((_ListProductCartItem[index].price) +
              (_ListProductCartItem[index].shippingCost)) *
          _ListProductCartItem[index].quantity;

      _TotalPriceShipping += _ListProductCartItem[index].shippingCost;
    }
    //print("Total is ${ShopCartPage.totalprice}");
    return totalprice;
  }

  Future<void> getShopCartItems({String UserId}) async {
    final url = baseurl.Urls.api + '/carts/' + UserId;
    //print(url);

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: Map<String, String>.from({
          'Authorization':
              'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjI3MDRlMWYwODIxMDk3ODIyYjMzMDM4NzM0MGE2MDJkNzgxM2RiYWJhMmViZmY1NGIyMDM5NmRlYzg2N2Y4ZTdkZTg0MDNjNzJjZTEyNGE1In0.eyJhdWQiOiIzIiwianRpIjoiMjcwNGUxZjA4MjEwOTc4MjJiMzMwMzg3MzQwYTYwMmQ3ODEzZGJhYmEyZWJmZjU0YjIwMzk2ZGVjODY3ZjhlN2RlODQwM2M3MmNlMTI0YTUiLCJpYXQiOjE2MTc4NzM4MDIsIm5iZiI6MTYxNzg3MzgwMiwiZXhwIjoxNjQ5NDA5ODAyLCJzdWIiOiIxMzciLCJzY29wZXMiOltdfQ.XH6HpOMbSPPogkHHMMYUItf_0T3NactuHLgGQCM7GVUModItAUvj1I8BPBFt3Q3wvNiRwp9xQBHL6TZL9Lq_BSeYTvXt8X2jYbBWHvfeYr3s1486b88f06WFYC7AGP3bXgsxs0zEEholZy20hNMeM4tP29ZR2nnpXIKkIV7JS1aUOqYqLoa3dLfBsQf3KSV9m30CNckLHVwItBZJXynNTcTURAWEDuBoLboqFj1qRcIJvVarSxPisPIKL1S9XkfRYENekMPt3d7uN9AJX7jrE-SoioQ3CPoqxo-ZA88J7MEL2OZjJjXqK6aOEFViN3mBfHSsF4K5gMgRP32q56w8AZ1_907iDGDyq36XeKt_EiAgePsFfLwVVkdn0ZYI8juOM95MadwZHx6EdXbQeX5cHhNerxS61ot-mCeGrIKCFJ-9aGuQz3WIU4FH5-hzqVIxE2BfPcQZ8pj3HyPlGj7zd0puN5ybXjYdI_A4gCQu9M7aTSsa3jWXllALIAQGnRSLggfSkL5CwkiIOWQRG2p_81Z-gA-USoLwG206sFNlo9uoIG31l3dWVXPAiwrIhjGCnyg-XFBFO8H_a8iqUgADQq4IjspcZzIlLKIKDdxKD0p3GDrg77UnudbcW8-2PBGSIxhvkF6gu0VC80pjR4kxXMjPwfAQcSBH01jrSe3F_eo'
        }),
      );
      // print("URL   : " + url.toString());
      // print("Response1  " + response.body.toString());

      final responseData = json.decode(response.body);

      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        throw HttpException('An Error occurred!');
      }

      var data = (responseData['data'] as List).map((data) {
        final extractedData = data as Map<String, dynamic>;

        return CartItem(
          id: extractedData['id'],
          productname: extractedData['product']['name'],
          productimage: extractedData['product']['image'],
          price: extractedData['price'],
          date: extractedData['date'],
          quantity: extractedData['quantity'],
          shippingCost: extractedData['shipping_cost'],
          shippingSlide: extractedData['shipping_slide'],
          tax: extractedData['tax'],
          variation: extractedData['variation'],
        );
      }).toList();

      _ListProductCartItem = data;
      //   print(_ListProductCartItem);
      _TotalPrice = CalcTotal().toDouble();
      notifyListeners();
    } catch (e) {
      print("Error  " + e);
      throw e;
    }
  }

  Future<void> EditNumOfquantity({
    int New_quantity,
    int Cart_id,
  }) async {
    final url = baseurl.Urls.api + '/carts/change-quantity';
    //print("Name is:  ${name}");
    print(url);
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: Map<String, String>.from({
          'Content-Type': 'application/json',
          'Authorization':
              'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjI3MDRlMWYwODIxMDk3ODIyYjMzMDM4NzM0MGE2MDJkNzgxM2RiYWJhMmViZmY1NGIyMDM5NmRlYzg2N2Y4ZTdkZTg0MDNjNzJjZTEyNGE1In0.eyJhdWQiOiIzIiwianRpIjoiMjcwNGUxZjA4MjEwOTc4MjJiMzMwMzg3MzQwYTYwMmQ3ODEzZGJhYmEyZWJmZjU0YjIwMzk2ZGVjODY3ZjhlN2RlODQwM2M3MmNlMTI0YTUiLCJpYXQiOjE2MTc4NzM4MDIsIm5iZiI6MTYxNzg3MzgwMiwiZXhwIjoxNjQ5NDA5ODAyLCJzdWIiOiIxMzciLCJzY29wZXMiOltdfQ.XH6HpOMbSPPogkHHMMYUItf_0T3NactuHLgGQCM7GVUModItAUvj1I8BPBFt3Q3wvNiRwp9xQBHL6TZL9Lq_BSeYTvXt8X2jYbBWHvfeYr3s1486b88f06WFYC7AGP3bXgsxs0zEEholZy20hNMeM4tP29ZR2nnpXIKkIV7JS1aUOqYqLoa3dLfBsQf3KSV9m30CNckLHVwItBZJXynNTcTURAWEDuBoLboqFj1qRcIJvVarSxPisPIKL1S9XkfRYENekMPt3d7uN9AJX7jrE-SoioQ3CPoqxo-ZA88J7MEL2OZjJjXqK6aOEFViN3mBfHSsF4K5gMgRP32q56w8AZ1_907iDGDyq36XeKt_EiAgePsFfLwVVkdn0ZYI8juOM95MadwZHx6EdXbQeX5cHhNerxS61ot-mCeGrIKCFJ-9aGuQz3WIU4FH5-hzqVIxE2BfPcQZ8pj3HyPlGj7zd0puN5ybXjYdI_A4gCQu9M7aTSsa3jWXllALIAQGnRSLggfSkL5CwkiIOWQRG2p_81Z-gA-USoLwG206sFNlo9uoIG31l3dWVXPAiwrIhjGCnyg-XFBFO8H_a8iqUgADQq4IjspcZzIlLKIKDdxKD0p3GDrg77UnudbcW8-2PBGSIxhvkF6gu0VC80pjR4kxXMjPwfAQcSBH01jrSe3F_eo',
        }),
        body: json.encode(
          {
            'id': Cart_id,
            'quantity': New_quantity,
          },
        ),
      );
//      print("ResADDresssss : ${response.body} ");
      final responseData = json.decode(response.body);
      //    print("ResponseDataUpdate   $responseData ");
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        throw HttpException('An Error occurred!');
      }

      _ListProductCartItem.forEach((element_main) {
        _ListProductCartItem[_ListProductCartItem.indexWhere(
                (element) => element.id == Cart_id)]
            .quantity = New_quantity;
      });

      _TotalPrice = CalcTotal().toDouble();
      notifyListeners();
    } catch (e) {
      print("E  " + e);
      throw e;
    }
  }

  Future DeleteCartItem({int Cartid}) async {
    final url = baseurl.Urls.api + '/carts/' + Cartid.toString();
    //print(url);
    // print(email);
    // print(password);

    try {
      final response = await http.delete(
        Uri.parse(url),
        headers: Map<String, String>.from(
          {
            'Authorization':
                'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjI3MDRlMWYwODIxMDk3ODIyYjMzMDM4NzM0MGE2MDJkNzgxM2RiYWJhMmViZmY1NGIyMDM5NmRlYzg2N2Y4ZTdkZTg0MDNjNzJjZTEyNGE1In0.eyJhdWQiOiIzIiwianRpIjoiMjcwNGUxZjA4MjEwOTc4MjJiMzMwMzg3MzQwYTYwMmQ3ODEzZGJhYmEyZWJmZjU0YjIwMzk2ZGVjODY3ZjhlN2RlODQwM2M3MmNlMTI0YTUiLCJpYXQiOjE2MTc4NzM4MDIsIm5iZiI6MTYxNzg3MzgwMiwiZXhwIjoxNjQ5NDA5ODAyLCJzdWIiOiIxMzciLCJzY29wZXMiOltdfQ.XH6HpOMbSPPogkHHMMYUItf_0T3NactuHLgGQCM7GVUModItAUvj1I8BPBFt3Q3wvNiRwp9xQBHL6TZL9Lq_BSeYTvXt8X2jYbBWHvfeYr3s1486b88f06WFYC7AGP3bXgsxs0zEEholZy20hNMeM4tP29ZR2nnpXIKkIV7JS1aUOqYqLoa3dLfBsQf3KSV9m30CNckLHVwItBZJXynNTcTURAWEDuBoLboqFj1qRcIJvVarSxPisPIKL1S9XkfRYENekMPt3d7uN9AJX7jrE-SoioQ3CPoqxo-ZA88J7MEL2OZjJjXqK6aOEFViN3mBfHSsF4K5gMgRP32q56w8AZ1_907iDGDyq36XeKt_EiAgePsFfLwVVkdn0ZYI8juOM95MadwZHx6EdXbQeX5cHhNerxS61ot-mCeGrIKCFJ-9aGuQz3WIU4FH5-hzqVIxE2BfPcQZ8pj3HyPlGj7zd0puN5ybXjYdI_A4gCQu9M7aTSsa3jWXllALIAQGnRSLggfSkL5CwkiIOWQRG2p_81Z-gA-USoLwG206sFNlo9uoIG31l3dWVXPAiwrIhjGCnyg-XFBFO8H_a8iqUgADQq4IjspcZzIlLKIKDdxKD0p3GDrg77UnudbcW8-2PBGSIxhvkF6gu0VC80pjR4kxXMjPwfAQcSBH01jrSe3F_eo'
          },
        ),
      );
      //print("URL   : " + url.toString());

      print("Response1  " + response.body.toString());
      final responseData = json.decode(response.body);

      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        throw HttpException('An Error occurred!');
      }

      _ListProductCartItem.removeAt(
        _ListProductCartItem.indexWhere((element) => element.id == Cartid),
      );
      //print("len");
      // print(_ListProductCartItem.length);
      _TotalPrice = CalcTotal().toDouble();
      notifyListeners();
    } catch (e) {
      print("E  " + e);
      throw e;
    }
  }
}
