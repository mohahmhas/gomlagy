import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/helpers/keys.dart';
import 'package:gomalgy/models/address.dart';
import 'package:gomalgy/providers/account_information.dart';
import '../helpers/base_url.dart' as baseurl;
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../helpers/http_exception.dart';

final checkOutDataProvider = ChangeNotifierProvider<CheckOutProvider>((ref) {
  return CheckOutProvider();
});

class CheckOutProvider extends ChangeNotifier {
  Future<void> SendCouponCode({String UserId, String Code}) async {
    final url = baseurl.Urls.api + '/coupon/apply';
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: Map<String, String>.from(
          {
            'Content-Type': 'application/json',
            'Authorization':
                'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjMyZmFkYjhiZjAyNTAyZmQzMzY2NWNmOWQ5NzRjYzMyNGE2NThmMDljYmM1MDdiYTk5ODJjODM1YjU5YmI4YzMxMTY1MWUyNmIzNGM2OTJmIn0.eyJhdWQiOiIzIiwianRpIjoiMzJmYWRiOGJmMDI1MDJmZDMzNjY1Y2Y5ZDk3NGNjMzI0YTY1OGYwOWNiYzUwN2JhOTk4MmM4MzViNTliYjhjMzExNjUxZTI2YjM0YzY5MmYiLCJpYXQiOjE2MTc3MDY4MTIsIm5iZiI6MTYxNzcwNjgxMiwiZXhwIjoxNjQ5MjQyODEyLCJzdWIiOiIxNjMiLCJzY29wZXMiOltdfQ.mccdVavA4r5OJxbTHZRelFzHsrVeU_6GbJd3RR_4fOBM1a8VvP-jTa2F0QRpPqAKsyVgV-hluULSajchChCPwXPaGWsWTyBReCOk5ugEi_5T0vuGXWkCDKEcAAdQc_WBwJXbCRamfbAuYG_5NP81urZXpYWM5p9WZJ7JahiS3js8fgWfHvYu_yCBHZ10SAtU56V_ujLSFOkhMWcQCi8IjPFlKQzoqNSNy2iMgXwACQjKDzi31jd46toWh9dv4DSZSwcaoyyW0ziNpJojFM2Vy207F7ofzYGAHbiinGeZq_RH6898hOAeDSFaYFGAqP5-GM87TCniKEZiIH9d2ul45YEvT7m4nJ2FksS3nnMnkT88bkQyONuOGWJzsNlnsPVzCH1xxmy0KMUXItOYdncfr0PqpZz9bFjjRNemUmm0SRVqxDR7CIJHk9cxUyet7VmgQRxJesZOM2L2rh4O-T9OKz4pAMjyT1jeRDzWcVfwH3xnnMr-kt6ohUYlUtrCHfLQZUaoWTfmaEgFKOaHQ4JgvFemnKhLtmzko4Yi9svyYNrE-U3gZsR_Lbp9vNjrx57v83DGnKSUeV0e7PXKSuSt87qIBnOLapNeocrWZlDgT1inIBSHF8s0mSqu17JkgQg_u-YA5wYagSa4hVdbSjk32B_WWMC7zJQQ2hseacNKOqc',
          },
        ),
        body: json.encode(
          {
            'code': Code,
            'user_id': UserId,
          },
        ),
      );
      //  print("ResAddAAddress  : ${response.body} ");
      final responseData = json.decode(response.body);
      //   print("data   $responseData ");
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        throw HttpException('An Error occurred!');
      }
    } catch (e) {
      print("E  " + e);
      throw e;
    }
  }

  Future<bool> payonDelivary({
    double GrandTotal,
  }) async {
    final url = baseurl.Urls.api + '/payments/pay/cod';

    final selectedaddress =
        Keys.navKey.currentContext.read(accountDataProvider).selectedAddress;

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: Map<String, String>.from(
          {
            'Content-Type': 'application/json',
            'Authorization':
                'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjJmMWIyOWY4Y2U1ODJhOGYwOWMwMWYxY2M1YTJhMmFjMTEzZTAxMGQ2ZmEzM2E3YjFlYjZlYjA0NTM4MjMzNDZhNWE4NDdjOTVkZmYxOGQ5In0.eyJhdWQiOiIzIiwianRpIjoiMmYxYjI5ZjhjZTU4MmE4ZjA5YzAxZjFjYzVhMmEyYWMxMTNlMDEwZDZmYTMzYTdiMWViNmViMDQ1MzgyMzM0NmE1YTg0N2M5NWRmZjE4ZDkiLCJpYXQiOjE2MTg4NDExNjgsIm5iZiI6MTYxODg0MTE2OCwiZXhwIjoxNjUwMzc3MTY4LCJzdWIiOiIxMzciLCJzY29wZXMiOltdfQ.KNNrYVFB59t9m-XZQ4yE7NsfiiVjMmAs1QHzmGL8aNNP2Y-16EkrM_Mt-URKpla0N-qyjx4uGuqM_iaG6kk7jjYIzGk0L92yxghX16BEDfoJUBWJ0fggnjL-Z3xkPIhww9ia6YnSANuMYLl5mjNrcr1roV0yal5o9I-DE42Z3a6hZAbV4YVmq9K3vkyTaLUqogEV8OrYr7-AHQ1VhCJj1hXkvBb9mQW47cMwms6Ogfyykl9VoM9inFzxI2fvWBhIyaPEpvbpCo8E6KeiN3KDcLIfT3DaqCzqJtcegAVtK-jHIMf09TZgO-X8p0_ei3H--q-w3tEbZHJLT5rl0qziMQ8INoBIZ3FDpuMcqL_4W40ANkbYktWGJRLUvu28tAjCO7MFTCeMqvkUou2tzltH__wm-Bj1unuQwi4eq1noysw-vFCooZBYFFLkObe0D2gHHrSCyrfus35HPobN8pbq-h4Chvprl3pVTjKe6wZRMIyR9eLnTvIJkOUpFu5zEPiOA1KhvVeDiPUGDn2vc2BsadpTzS_LrmWD3YKlDpdpHxLOD4ij9skxmzQgySGnxWWpn84mSm2NWqRcvzD8v5fjyizTl6JREtRIqFwHDWauADq0zbWEErSx6_uoEk38J_E0b-j2LWlLtn9HCNrykRf_p9o_SiGpqOfmfrRdnupCEyI',
          },
        ),
        body: json.encode(
          {
            'shipping_address': {
              'name': 'nnnnnnnnnnnnnnnnnnnnnnnn',
              'email': 'eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',
              // 'address': selectedaddress['addressdetails'],
              // 'country': selectedaddress['country'],
              // 'city': selectedaddress['city'],
              // 'postal_code': selectedaddress['postalCode'],
              // 'phone': selectedaddress['phone'],
              'address': 'addressdetails',
              'country': 'country',
              'city': 'city',
              'postal_code': 'postalCode',
              'phone': 'phone',
              'checkout_type': 'logged',
            },
            'payment_type': 'cod',
            'payment_status': 'unpaid',
            'grand_total': GrandTotal,
            'user_id': 137,
            'coupon_discount': 0.0,
            'coupon_code': '',
          },
        ),
      );
      print("ResAddAAddress  : ${response.body} ");
      final responseData = json.decode(response.body);
      print("data   $responseData ");
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        throw HttpException('An Error occurred!');
      }

      if (responseData["message"] ==
          "Your order has been placed successfully") {
        print('successfully');
        SendEmail(UserId: 137);
        return true;
      }
      return true;
    } catch (e) {
      print("E  " + e);
      return false;
    }
  }

  Future<void> SendEmail({int UserId}) async {
    final url = baseurl.Urls.api + '/send-email';
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: Map<String, String>.from(
          {
            'Content-Type': 'application/json',
            'Authorization':
                'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjMyZmFkYjhiZjAyNTAyZmQzMzY2NWNmOWQ5NzRjYzMyNGE2NThmMDljYmM1MDdiYTk5ODJjODM1YjU5YmI4YzMxMTY1MWUyNmIzNGM2OTJmIn0.eyJhdWQiOiIzIiwianRpIjoiMzJmYWRiOGJmMDI1MDJmZDMzNjY1Y2Y5ZDk3NGNjMzI0YTY1OGYwOWNiYzUwN2JhOTk4MmM4MzViNTliYjhjMzExNjUxZTI2YjM0YzY5MmYiLCJpYXQiOjE2MTc3MDY4MTIsIm5iZiI6MTYxNzcwNjgxMiwiZXhwIjoxNjQ5MjQyODEyLCJzdWIiOiIxNjMiLCJzY29wZXMiOltdfQ.mccdVavA4r5OJxbTHZRelFzHsrVeU_6GbJd3RR_4fOBM1a8VvP-jTa2F0QRpPqAKsyVgV-hluULSajchChCPwXPaGWsWTyBReCOk5ugEi_5T0vuGXWkCDKEcAAdQc_WBwJXbCRamfbAuYG_5NP81urZXpYWM5p9WZJ7JahiS3js8fgWfHvYu_yCBHZ10SAtU56V_ujLSFOkhMWcQCi8IjPFlKQzoqNSNy2iMgXwACQjKDzi31jd46toWh9dv4DSZSwcaoyyW0ziNpJojFM2Vy207F7ofzYGAHbiinGeZq_RH6898hOAeDSFaYFGAqP5-GM87TCniKEZiIH9d2ul45YEvT7m4nJ2FksS3nnMnkT88bkQyONuOGWJzsNlnsPVzCH1xxmy0KMUXItOYdncfr0PqpZz9bFjjRNemUmm0SRVqxDR7CIJHk9cxUyet7VmgQRxJesZOM2L2rh4O-T9OKz4pAMjyT1jeRDzWcVfwH3xnnMr-kt6ohUYlUtrCHfLQZUaoWTfmaEgFKOaHQ4JgvFemnKhLtmzko4Yi9svyYNrE-U3gZsR_Lbp9vNjrx57v83DGnKSUeV0e7PXKSuSt87qIBnOLapNeocrWZlDgT1inIBSHF8s0mSqu17JkgQg_u-YA5wYagSa4hVdbSjk32B_WWMC7zJQQ2hseacNKOqc',
          },
        ),
        body: json.encode(
          {
            'user_id': UserId,
          },
        ),
      );
      //  print("ResAddAAddress  : ${response.body} ");
      final responseData = json.decode(response.body);
      //   print("data   $responseData ");
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        throw HttpException('An Error occurred!');
      }
    } catch (e) {
      print("E  " + e);
      throw e;
    }
  }
}
