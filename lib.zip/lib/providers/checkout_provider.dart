import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gomalgy/helpers/keys.dart';
import 'package:gomalgy/models/address.dart';
import 'package:gomalgy/providers/account_information.dart';
import '../helpers/base_url.dart' as baseurl;
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../helpers/http_exception.dart';
import 'auth.dart';

final checkOutDataProvider = ChangeNotifierProvider<CheckOutProvider>((ref) {
  return CheckOutProvider();
});

class CheckOutProvider extends ChangeNotifier {
  Future<void> SendCouponCode({String Code}) async {
    final url = baseurl.Urls.api + '/coupon/apply';
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: Map<String, String>.from(
          {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' +
                Keys.navKey.currentContext.read(authDataProvider).token,
          },
        ),
        body: json.encode(
          {
            'code': Code,
            'user_id': Keys.navKey.currentContext.read(authDataProvider).userId,
          },
        ),
      );
      //  print("ResAddAAddress  : ${response.body} ");
      final responseData = json.decode(response.body);
      //   print("data   $responseData ");
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        throw HttpException('An Error occurred!');
      }
    } catch (e) {
      print("E  " + e);
      throw e;
    }
  }

  Future<bool> payonDelivary({
    double GrandTotal,
  }) async {
    final url = baseurl.Urls.api + '/payments/pay/cod';

    final selectedaddress =
        Keys.navKey.currentContext.read(accountDataProvider).selectedAddress;

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: Map<String, String>.from(
          {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' +
                Keys.navKey.currentContext.read(authDataProvider).token,
          },
        ),
        body: json.encode(
          {
            'shipping_address': {
              'name': 'nnnnnnnnnnnnnnnnnnnnnnnn',
              'email': 'eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',
              // 'address': selectedaddress['addressdetails'],
              // 'country': selectedaddress['country'],
              // 'city': selectedaddress['city'],
              // 'postal_code': selectedaddress['postalCode'],
              // 'phone': selectedaddress['phone'],
              'address': 'addressdetails',
              'country': 'country',
              'city': 'city',
              'postal_code': 'postalCode',
              'phone': 'phone',
              'checkout_type': 'logged',
            },
            'payment_type': 'cod',
            'payment_status': 'unpaid',
            'grand_total': GrandTotal,
            'user_id': 137,
            'coupon_discount': 0.0,
            'coupon_code': '',
          },
        ),
      );
      print("ResAddAAddress  : ${response.body} ");
      final responseData = json.decode(response.body);
      print("data   $responseData ");
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        throw HttpException('An Error occurred!');
      }

      if (responseData["message"] ==
          "Your order has been placed successfully") {
        print('successfully');
        SendEmail();
        return true;
      }
      return true;
    } catch (e) {
      print("E  " + e);
      return false;
    }
  }

  Future<void> SendEmail() async {
    final url = baseurl.Urls.api + '/send-email';
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: Map<String, String>.from(
          {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' +
                Keys.navKey.currentContext.read(authDataProvider).token,
          },
        ),
        body: json.encode(
          {
            'user_id': Keys.navKey.currentContext.read(authDataProvider).userId,
          },
        ),
      );
      //  print("ResAddAAddress  : ${response.body} ");
      final responseData = json.decode(response.body);
      //   print("data   $responseData ");
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      if (response.statusCode >= 400) {
        throw HttpException('An Error occurred!');
      }
    } catch (e) {
      print("E  " + e);
      throw e;
    }
  }
}
