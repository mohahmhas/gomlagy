import 'dart:convert';

import 'package:gomalgy/helpers/base_url.dart';
import 'package:gomalgy/models/product_categories_model.dart';
import 'package:gomalgy/models/see_all_model.dart';
import 'package:gomalgy/models/subProduct_categories_model.dart';

import 'package:http/http.dart';

abstract class CategoriesApi {
  static List<dynamic> list = [];
  static int lengthOfList;

  static Future<List<CategoriesData>> getCategoriesNames(
      String endPoint) async {
    final Response response = await get(Uri.parse(Urls.api + endPoint));
    try {
      if (response.statusCode == 200) {
        // parsing json into List of objects
        final parsed = json.decode(response.body).cast<String, dynamic>();
        return parsed['data']
            .map<CategoriesData>((item) => CategoriesData.fromJson(item))
            .toList();
      }
    } catch (e) {
      print(e);
    }
    return null;
  } // end getCategoriesNames()

  static Future<List<Products>> getSubCategoriesData(
      String endPoint, int index) async {
    final Response response = await get(Uri.parse(Urls.api + endPoint));
    // print('Response $response');
    try {
      if (response.statusCode == 200) {
        // parsing json into List of objects
        final parsed = json.decode(response.body).cast<String, dynamic>();
        return parsed['data'][index]['products']
            .map<Products>((item) => Products.fromJson(item))
            .toList();
      }
    } catch (e) {
      print(e);
    }
    return null;
  } // end getCategoriesNames()

  static Future<List<SeeAllDataModel>> SeeAllProducts(String url) async {
    final Response response = await get(Uri.parse(url));
    // print('Response $response');
    try {
      if (response.statusCode == 200) {
        // parsing json into List of objects
        final parsed = json.decode(response.body).cast<String, dynamic>();
        print('parsed of data' + parsed['data'].toString());
        return parsed['data']
            .map<SeeAllDataModel>((item) => SeeAllDataModel.fromJson(item))
            .toList();
      } // end if
    } catch (e) {
      print(e);
    }
    return null;
  }
} // end class
