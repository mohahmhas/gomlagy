class ProductDetailsList {
  String nameProduct;
  String namemodel;
  int numofquantity;
  String productid;
  var color;

  ProductDetailsList({
    this.nameProduct,
    this.namemodel,
    this.numofquantity,
    this.color,
    this.productid,
  });
}
