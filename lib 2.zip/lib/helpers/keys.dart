import 'package:flutter/material.dart';

class Keys {
  static final GlobalKey<NavigatorState> navKey =
      new GlobalKey<NavigatorState>();
}
